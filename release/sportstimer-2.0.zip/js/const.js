'use strict';

// Constantes.
const STATE_EX_EFFORT = 1;
const STATE_EX_RECOVERY = 2;
const STATE_EX_PAUSE = 3;
// 
const STATE_EX_BETWEEN = 4;
const dbName = "exerciceData";

const dbVersion = 33;

const EFFORT_COLOR = '#F97C17'; 